<?php
/**
 * Plugin Name: Hashoo POS for WooCommerce
 * Description: Front-end POS for WooCommerce (product grid, cart, pay, change, receipt print) + cashier lockdown + business settings.
 * Version: 1.0.2
 * Author: Hashoo
 */

if (!defined('ABSPATH')) exit;

class Hashoo_POS_Plugin {
  const NONCE_ACTION = 'hashoo_pos_nonce_action';
  const OPT_SETTINGS = 'hashoo_pos_settings';
  const OPT_PAGE_ID  = 'hashoo_pos_page_id';

  public function __construct() {
    // Admin menu + settings
    add_action('admin_menu', [$this, 'admin_menu']);
    add_action('admin_init', [$this, 'register_settings']);

    // Shortcode + assets
    add_shortcode('hashoo_pos', [$this, 'render_frontend_pos']);
    add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);

    // Standalone POS template (no theme header/footer)
    add_action('template_redirect', [$this, 'maybe_render_pos_standalone']);

    // Cashier UX: hide admin bar + redirect away from wp-admin
    add_filter('show_admin_bar', [$this, 'maybe_hide_admin_bar']);
    add_action('admin_init', [$this, 'block_cashier_from_admin']);
    add_filter('login_redirect', [$this, 'cashier_login_redirect'], 10, 3);

    // AJAX (logged in)
    add_action('wp_ajax_hashoo_pos_get_products', [$this, 'ajax_get_products']);
    add_action('wp_ajax_hashoo_pos_create_order', [$this, 'ajax_create_order']);

    // Speed: block emails for POS orders
    add_filter('woocommerce_email_recipient_new_order', [$this, 'maybe_block_pos_emails'], 10, 2);
    add_filter('woocommerce_email_recipient_customer_processing_order', [$this, 'maybe_block_pos_emails'], 10, 2);
    add_filter('woocommerce_email_recipient_customer_completed_order', [$this, 'maybe_block_pos_emails'], 10, 2);
    add_filter('woocommerce_email_recipient_customer_on_hold_order', [$this, 'maybe_block_pos_emails'], 10, 2);
    add_filter('woocommerce_email_recipient_customer_invoice', [$this, 'maybe_block_pos_emails'], 10, 2);
  }

  // ---------------------------
  // Activation helpers
  // ---------------------------
  public static function activate() {
    // Cashier role
    add_role('hashoo_cashier', 'Hashoo Cashier', [
      'read' => true,
      'hashoo_pos_access' => true,
    ]);

    // Auto-create POS page if not exists
    $existing_id = get_option(self::OPT_PAGE_ID);
    if ($existing_id && get_post($existing_id)) {
      flush_rewrite_rules();
      return;
    }

    $page = get_page_by_path('pos');
    if ($page && isset($page->ID)) {
      update_option(self::OPT_PAGE_ID, (int)$page->ID);
      flush_rewrite_rules();
      return;
    }

    $page_id = wp_insert_post([
      'post_title'   => 'POS',
      'post_name'    => 'pos',
      'post_status'  => 'publish',
      'post_type'    => 'page',
      'post_content' => '[hashoo_pos]',
    ]);

    if (!is_wp_error($page_id) && $page_id) {
      update_option(self::OPT_PAGE_ID, (int)$page_id);
    }

    flush_rewrite_rules();
  }

  public static function deactivate() {
    flush_rewrite_rules();
  }

  private function pos_url() {
    $pid = (int) get_option(self::OPT_PAGE_ID);
    if ($pid && get_post($pid)) return get_permalink($pid);
    return home_url('/pos/');
  }

  private function is_pos_page() {
    $pid = (int) get_option(self::OPT_PAGE_ID);
    return ($pid && is_page($pid));
  }

  // ---------------------------
  // Admin: Menu + Settings
  // ---------------------------
  public function admin_menu() {
    add_menu_page(
      'Hashoo POS',
      'Hashoo POS',
      'manage_woocommerce',
      'hashoo-pos',
      [$this, 'render_admin_home'],
      'dashicons-store',
      56
    );

    add_submenu_page(
      'hashoo-pos',
      'Settings',
      'Settings',
      'manage_woocommerce',
      'hashoo-pos-settings',
      [$this, 'render_settings_page']
    );
  }

  public function render_admin_home() {
    if (!current_user_can('manage_woocommerce')) wp_die('No permission.');

    $pos_url = esc_url($this->pos_url());

    echo '<div class="wrap"><h1>Hashoo POS</h1>';

    echo '<p style="margin:12px 0 18px;">';
    echo '<a class="button button-primary button-large" href="'.$pos_url.'" target="_blank" rel="noopener">See POS</a>';
    echo '</p>';

    echo '<p><strong>Shortcode:</strong> <code>[hashoo_pos]</code></p>';
    echo '<p>Create cashier users via <strong>Users → Add New</strong> and assign role <strong>Hashoo Cashier</strong>.</p>';

    echo '</div>';
  }

  public function register_settings() {
    register_setting('hashoo_pos_settings_group', self::OPT_SETTINGS, [
      'type' => 'array',
      'sanitize_callback' => [$this, 'sanitize_settings'],
      'default' => [
        'business_name' => '',
        'phone' => '',
        'address' => '',
      ],
    ]);

    add_settings_section('hashoo_pos_main', 'Business Details', function () {
      echo '<p>These details appear on POS header and receipt.</p>';
    }, 'hashoo-pos-settings');

    add_settings_field('business_name', 'Business Name', [$this, 'field_business_name'], 'hashoo-pos-settings', 'hashoo_pos_main');
    add_settings_field('phone', 'Phone Number', [$this, 'field_phone'], 'hashoo-pos-settings', 'hashoo_pos_main');
    add_settings_field('address', 'Address', [$this, 'field_address'], 'hashoo-pos-settings', 'hashoo_pos_main');
  }

  public function sanitize_settings($input) {
    return [
      'business_name' => isset($input['business_name']) ? sanitize_text_field($input['business_name']) : '',
      'phone'         => isset($input['phone']) ? sanitize_text_field($input['phone']) : '',
      'address'       => isset($input['address']) ? sanitize_textarea_field($input['address']) : '',
    ];
  }

  private function settings() {
    $opt = get_option(self::OPT_SETTINGS, []);
    return wp_parse_args($opt, [
      'business_name' => '',
      'phone' => '',
      'address' => '',
    ]);
  }

  public function field_business_name() {
    $s = $this->settings();
    printf('<input type="text" class="regular-text" name="%s[business_name]" value="%s" />',
      esc_attr(self::OPT_SETTINGS),
      esc_attr($s['business_name'])
    );
  }

  public function field_phone() {
    $s = $this->settings();
    printf('<input type="text" class="regular-text" name="%s[phone]" value="%s" />',
      esc_attr(self::OPT_SETTINGS),
      esc_attr($s['phone'])
    );
  }

  public function field_address() {
    $s = $this->settings();
    printf('<textarea class="large-text" rows="4" name="%s[address]">%s</textarea>',
      esc_attr(self::OPT_SETTINGS),
      esc_textarea($s['address'])
    );
  }

  public function render_settings_page() {
    if (!current_user_can('manage_woocommerce')) wp_die('No permission.');
    echo '<div class="wrap"><h1>Hashoo POS Settings</h1>';
    echo '<form method="post" action="options.php">';
    settings_fields('hashoo_pos_settings_group');
    do_settings_sections('hashoo-pos-settings');
    submit_button('Save Settings');
    echo '</form></div>';
  }

  // ---------------------------
  // Cashier lockdown
  // ---------------------------
  public function maybe_hide_admin_bar($show) {
    if (current_user_can('hashoo_pos_access') && !current_user_can('manage_woocommerce')) return false;
    return $show;
  }

  public function block_cashier_from_admin() {
    if (defined('DOING_AJAX') && DOING_AJAX) return;
    if (function_exists('wp_doing_ajax') && wp_doing_ajax()) return;

    if (current_user_can('hashoo_pos_access') && !current_user_can('manage_woocommerce')) {
      wp_safe_redirect($this->pos_url());
      exit;
    }
  }

  public function cashier_login_redirect($redirect_to, $requested, $user) {
    if (!$user || is_wp_error($user)) return $redirect_to;
    if (user_can($user, 'hashoo_pos_access') && !user_can($user, 'manage_woocommerce')) {
      return $this->pos_url();
    }
    return $redirect_to;
  }

  private function has_pos_access() {
    return is_user_logged_in() && (current_user_can('manage_woocommerce') || current_user_can('hashoo_pos_access'));
  }

  // ---------------------------
  // Standalone POS page (no theme header/footer)
  // ---------------------------
  public function maybe_render_pos_standalone() {
    if (!$this->is_pos_page()) return;

    // Not logged in -> go login
    if (!is_user_logged_in()) {
      wp_safe_redirect(wp_login_url($this->pos_url()));
      exit;
    }

    // No access
    if (!$this->has_pos_access()) {
      status_header(403);
      echo '<div style="padding:16px;border:1px solid #fecaca;border-radius:12px;background:#fff;margin:20px;">No POS access.</div>';
      exit;
    }

    // Render a minimal page
    status_header(200);
    nocache_headers();

    ?><!doctype html>
    <html <?php language_attributes(); ?>>
      <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php wp_head(); ?>
      </head>
      <body <?php body_class('hashoo-pos-standalone'); ?>>
        <?php
          if (function_exists('wp_body_open')) wp_body_open();
          echo do_shortcode('[hashoo_pos]');
        ?>
        <?php wp_footer(); ?>
      </body>
    </html><?php
    exit;
  }

  // ---------------------------
  // Front-end POS (UI wrapper)
  // ---------------------------
  public function render_frontend_pos() {
    if (!is_user_logged_in()) {
      $login_url = wp_login_url($this->pos_url());
      return '<div style="padding:16px;border:1px solid #e5e7eb;border-radius:12px;background:#fff;">
        Please login to access POS. <a href="'.esc_url($login_url).'">Login</a>
      </div>';
    }

    if (!$this->has_pos_access()) {
      return '<div style="padding:16px;border:1px solid #fecaca;border-radius:12px;background:#fff;">
        You do not have access to POS.
      </div>';
    }

    $s = $this->settings();
    $biz_name = $s['business_name'] ? $s['business_name'] : get_bloginfo('name');

    ob_start(); ?>
      <div class="hashoo-shell">
        <header class="hashoo-header">
          <div class="hashoo-biz"><?php echo esc_html($biz_name); ?></div>
          <?php if (!empty($s['phone'])): ?>
            <div class="hashoo-phone"><?php echo esc_html($s['phone']); ?></div>
          <?php endif; ?>
        </header>

        <main class="hashoo-main">
          <div id="hashoo-pos-app"></div>
        </main>

        <footer class="hashoo-footer">
          <?php echo !empty($s['address']) ? nl2br(esc_html($s['address'])) : ''; ?>
        </footer>
      </div>
    <?php
    return ob_get_clean();
  }

  public function enqueue_frontend_assets() {
    if (!$this->has_pos_access()) return;

    // enqueue only on POS page OR pages containing shortcode
    if (!$this->is_pos_page()) {
      if (!is_singular()) return;
      global $post;
      if (!$post || !has_shortcode($post->post_content, 'hashoo_pos')) return;
    }

    $base = plugin_dir_url(__FILE__);
    $ver_css = file_exists(__DIR__.'/assets/pos.css') ? filemtime(__DIR__.'/assets/pos.css') : '1.0.2';
    $ver_js  = file_exists(__DIR__.'/assets/pos.js') ? filemtime(__DIR__.'/assets/pos.js') : '1.0.2';

    wp_enqueue_style('hashoo-pos-css', $base . 'assets/pos.css', [], $ver_css);
    wp_enqueue_script('hashoo-pos-js', $base . 'assets/pos.js', ['jquery'], $ver_js, true);

    $s = $this->settings();
    $biz_name = $s['business_name'] ? $s['business_name'] : get_bloginfo('name');

    wp_localize_script('hashoo-pos-js', 'HASHOO_POS', [
      'ajaxUrl'  => admin_url('admin-ajax.php'),
      'nonce'    => wp_create_nonce(self::NONCE_ACTION),
      'beepUrl'  => $base . 'assets/beep.mp3',
      'currency' => function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : '$',
      'biz' => [
        'name'    => $biz_name,
        'phone'   => $s['phone'],
        'address' => $s['address'],
      ],
    ]);
  }

  // ---------------------------
  // Email blocking for POS orders
  // ---------------------------
  public function maybe_block_pos_emails($recipient, $order) {
    if (!$order || !is_a($order, 'WC_Order')) return $recipient;

    $created_via = method_exists($order, 'get_created_via') ? $order->get_created_via() : '';
    $meta_via    = $order->get_meta('_created_via', true);

    if ($created_via === 'hashoo_pos' || $meta_via === 'hashoo_pos') {
      return ''; // no recipient => Woo won't send
    }
    return $recipient;
  }

  // ---------------------------
  // AJAX helpers
  // ---------------------------
  private function verify_ajax() {
    if (!$this->has_pos_access()) wp_send_json_error(['message' => 'Unauthorized'], 403);

    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, self::NONCE_ACTION)) {
      wp_send_json_error(['message' => 'Invalid nonce'], 400);
    }

    if (!class_exists('WooCommerce')) {
      wp_send_json_error(['message' => 'WooCommerce not active'], 400);
    }
  }

  private function hashoo_clear_buffers() {
    while (ob_get_level() > 0) {
      ob_end_clean();
    }
  }

  /**
   * For variable products: pick first purchasable/in-stock variation
   */
  private function first_variation_for_variable($variable_product) {
    if (!$variable_product || !$variable_product->is_type('variable')) return null;
    $children = $variable_product->get_children();
    if (empty($children)) return null;

    foreach ($children as $vid) {
      $v = wc_get_product($vid);
      if ($v && $v->is_purchasable() && $v->is_in_stock()) {
        return ['id' => $v->get_id(), 'price' => (float)$v->get_price()];
      }
    }
    return null;
  }

  // ---------------------------
  // AJAX: Products list (paged) + search
  // ---------------------------
  public function ajax_get_products() {
    $this->verify_ajax();

    $term     = isset($_POST['term']) ? sanitize_text_field($_POST['term']) : '';
    $page     = isset($_POST['page']) ? max(1, (int)$_POST['page']) : 1;
    $per_page = isset($_POST['per_page']) ? min(60, max(12, (int)$_POST['per_page'])) : 24;

    $query_args = [
      'post_type'      => 'product',
      'post_status'    => 'publish',
      'posts_per_page' => $per_page,
      'paged'          => $page,
      'orderby'        => 'title',
      'order'          => 'ASC',
      'fields'         => 'ids',
    ];

    if ($term !== '') {
      $query_args['s'] = $term; // title/content search (multi-word works)
    }

    $q = new WP_Query($query_args);
    $ids = $q->posts;

    // fallback SKU search if none found
    if ($term !== '' && empty($ids)) {
      $q2 = new WP_Query([
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => $per_page,
        'paged'          => $page,
        'orderby'        => 'title',
        'order'          => 'ASC',
        'fields'         => 'ids',
        'meta_query'     => [
          [
            'key'     => '_sku',
            'value'   => $term,
            'compare' => 'LIKE',
          ]
        ]
      ]);
      $ids = $q2->posts;
      $max_pages = (int)$q2->max_num_pages;
    } else {
      $max_pages = (int)$q->max_num_pages;
    }

    $out = [];

    foreach ($ids as $pid) {
      $p = wc_get_product($pid);
      if (!$p) continue;

      $img = wp_get_attachment_image_url($p->get_image_id(), 'thumbnail');

      $add_id   = $p->get_id();
      $price    = (float) $p->get_price();
      $in_stock = $p->is_in_stock();

      if ($p->is_type('variable')) {
        $pick = $this->first_variation_for_variable($p);
        if ($pick) {
          $add_id = (int) $pick['id'];
          $price  = (float) $pick['price'];
          $in_stock = true;
        } else {
          $in_stock = false;
        }
      }

      $out[] = [
        'id'         => (int) $p->get_id(),
        'add_id'     => (int) $add_id,
        'name'       => $p->get_name(),
        'sku'        => $p->get_sku(),
        'img'        => $img ? $img : '',
        'type'       => $p->get_type(),
        'price'      => $price,
        'in_stock'   => $in_stock ? 1 : 0,
        'stock_text' => $in_stock ? 'In stock' : 'Out of stock',
      ];
    }

    $this->hashoo_clear_buffers();
    wp_send_json_success([
      'products' => $out,
      'page'     => $page,
      'per_page' => $per_page,
      'has_more' => ($page < $max_pages) ? 1 : 0
    ]);
  }

  // ---------------------------
  // AJAX: Create order + receipt (fast + reliable)
  // ---------------------------
  public function ajax_create_order() {
    $this->verify_ajax();

    $items_json  = isset($_POST['items']) ? wp_unslash($_POST['items']) : '[]';
    $items       = json_decode($items_json, true);
    $paid_amount = isset($_POST['paid_amount']) ? (float)$_POST['paid_amount'] : 0.0;
    $pay_type    = isset($_POST['payment_type']) ? sanitize_text_field($_POST['payment_type']) : 'cash';

    if (!is_array($items) || empty($items)) {
      $this->hashoo_clear_buffers();
      wp_send_json_error(['message' => 'Cart is empty'], 400);
    }

    try {
      $order = wc_create_order();
      $order->set_customer_id(get_current_user_id());

      // mark POS early + save
      if (method_exists($order, 'set_created_via')) {
        $order->set_created_via('hashoo_pos');
      }
      $order->update_meta_data('_created_via', 'hashoo_pos');
      $order->save();

      $added = 0;
      foreach ($items as $it) {
        $pid = isset($it['product_id']) ? (int)$it['product_id'] : 0;
        $qty = isset($it['qty']) ? (int)$it['qty'] : 1;
        if ($pid < 1 || $qty < 1) continue;

        $prod = wc_get_product($pid);
        if (!$prod || !$prod->is_purchasable() || !$prod->is_in_stock()) continue;

        $item_id = $order->add_product($prod, $qty);
        if ($item_id) $added++;
      }

      if ($added === 0) {
        wp_delete_post($order->get_id(), true);
        $this->hashoo_clear_buffers();
        wp_send_json_error(['message' => 'No valid in-stock products were added to the order.'], 400);
      }

      $order->calculate_totals();
      $total = (float)$order->get_total();

      if ($total <= 0) {
        wp_delete_post($order->get_id(), true);
        $this->hashoo_clear_buffers();
        wp_send_json_error(['message' => 'Order total is invalid.'], 400);
      }

      if ($paid_amount < $total) {
        $this->hashoo_clear_buffers();
        wp_send_json_error(['message' => 'Paid amount must be equal or greater than total.'], 400);
      }

      $change = $paid_amount - $total;

      // store POS meta
      $order->update_meta_data('_hashoo_pos_paid_amount', $paid_amount);
      $order->update_meta_data('_hashoo_pos_change', $change);
      $order->update_meta_data('_hashoo_pos_payment_type', $pay_type);

      // set payment method to avoid edge cases
      if ($pay_type === 'card') {
        $order->set_payment_method('bacs');
        $order->set_payment_method_title('Card');
      } else {
        $order->set_payment_method('cod');
        $order->set_payment_method_title('Cash');
      }

      $order->save();

      // complete payment (reduces stock, etc)
      $order->payment_complete();

      $order->add_order_note(
        'Hashoo POS: Paid in full ('.$pay_type.'). Paid: '.wc_price($paid_amount).' Change: '.wc_price($change)
      );
      $order->save();

      $this->hashoo_clear_buffers();

      wp_send_json_success([
        'order_id'     => $order->get_id(),
        'total'        => $total,
        'paid_amount'  => $paid_amount,
        'change'       => $change,
        'receipt_html' => $this->receipt_html($order),
      ]);
    } catch (Exception $e) {
      $this->hashoo_clear_buffers();
      wp_send_json_error(['message' => $e->getMessage()], 500);
    }
  }

  private function receipt_html($order) {
    $s = $this->settings();
    $biz = $s['business_name'] ? $s['business_name'] : get_bloginfo('name');

    $phone   = $s['phone'];
    $address = $s['address'];

    $id   = (int)$order->get_id();
    $date = esc_html($order->get_date_created() ? $order->get_date_created()->date_i18n('Y-m-d H:i') : date('Y-m-d H:i'));

    $paid   = (float)$order->get_meta('_hashoo_pos_paid_amount', true);
    $change = (float)$order->get_meta('_hashoo_pos_change', true);
    $ptype  = esc_html($order->get_meta('_hashoo_pos_payment_type', true));

    ob_start(); ?>
      <div class="hashoo-receipt">
        <div class="hashoo-receipt__header">
          <div class="r-biz"><?php echo esc_html($biz); ?></div>
          <?php if ($phone): ?><div class="r-phone"><?php echo esc_html($phone); ?></div><?php endif; ?>
        </div>

        <div class="r-meta">
          <div><strong>Receipt #</strong><?php echo $id; ?></div>
          <div><?php echo $date; ?></div>
          <div>Payment: <?php echo $ptype ? $ptype : 'cash'; ?></div>
        </div>

        <hr />

        <table class="hashoo-receipt__table">
          <thead>
            <tr><th>Item</th><th>Qty</th><th>Total</th></tr>
          </thead>
          <tbody>
            <?php foreach ($order->get_items() as $item): ?>
              <tr>
                <td><?php echo esc_html($item->get_name()); ?></td>
                <td><?php echo (int)$item->get_quantity(); ?></td>
                <td><?php echo wp_kses_post(wc_price($item->get_total() + $item->get_total_tax())); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <hr />

        <div class="hashoo-receipt__totals">
          <div><span>Total</span><span><?php echo wp_kses_post(wc_price($order->get_total())); ?></span></div>
          <div><span>Paid</span><span><?php echo wp_kses_post(wc_price($paid)); ?></span></div>
          <div><span>Change</span><span><?php echo wp_kses_post(wc_price(max(0, $change))); ?></span></div>
        </div>

        <?php if ($address): ?>
          <div class="hashoo-receipt__footerbar"><?php echo nl2br(esc_html($address)); ?></div>
        <?php endif; ?>
      </div>
    <?php
    return ob_get_clean();
  }
}

// Boot
$hashoo_pos_plugin = new Hashoo_POS_Plugin();
register_activation_hook(__FILE__, ['Hashoo_POS_Plugin', 'activate']);
register_deactivation_hook(__FILE__, ['Hashoo_POS_Plugin', 'deactivate']);
