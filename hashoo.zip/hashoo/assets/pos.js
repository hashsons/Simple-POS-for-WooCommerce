(function ($) {
  let cart = [];
  let productsCache = [];
  let page = 1;
  let term = '';
  let loading = false;
  let hasMore = true;
  const PER_PAGE = 24;

  // ✅ Beep sound on add-to-cart
  let beepAudio = null;

  function initBeep() {
    if (!window.HASHOO_POS || !HASHOO_POS.beepUrl) return;
    beepAudio = new Audio(HASHOO_POS.beepUrl);
    beepAudio.preload = 'auto';
    beepAudio.volume = 0.6;
  }

  function playBeep() {
    try {
      if (!beepAudio) return;
      beepAudio.currentTime = 0;
      beepAudio.play();
    } catch (e) {}
  }

  function money(v) {
    const n = Number(v || 0);
    return `${HASHOO_POS.currency}${n.toFixed(2)}`;
  }

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, s => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
    }[s]));
  }

  function calcTotal() {
    return cart.reduce((sum, it) => sum + (it.price * it.qty), 0);
  }

  function itemCount() {
    return cart.reduce((s, i) => s + i.qty, 0);
  }

  function renderApp() {
    const html = `
      <div class="hashoo-pos">
        <div class="hashoo-left">
          <div class="hashoo-searchbar">
            <input id="hashoo-search" class="hashoo-input" placeholder="Search products..." />
          </div>

          <div id="hashoo-products" class="hashoo-products-grid"></div>
          <div id="hashoo-loader" class="hashoo-loader">Loading…</div>
        </div>

        <div class="hashoo-right">
          <div class="hashoo-right-header">
            <div class="hashoo-title">Cart</div>
            <div class="hashoo-pill"><span id="hashoo-count">0</span> items</div>
          </div>

          <div id="hashoo-cart" class="hashoo-cart"></div>

          <div class="hashoo-summary">
            <div class="row"><span>Total</span><span id="hashoo-total">${money(calcTotal())}</span></div>

            <div class="row pay">
              <label>Paid</label>
              <input id="hashoo-paid" class="hashoo-input" type="number" step="0.01" value="0" />
            </div>

            <div class="row"><span>Change</span><span id="hashoo-change">${money(0)}</span></div>

            <div id="hashoo-msg" class="hashoo-msg"></div>

            <div class="hashoo-actions">
              <select id="hashoo-payment" class="hashoo-select">
                <option value="cash">Cash</option>
                <option value="card">Card (manual)</option>
              </select>
              <button id="hashoo-pay" class="hashoo-btn" disabled>Pay Now</button>
            </div>
          </div>
        </div>

        <div class="hashoo-modal" id="hashoo-modal">
          <div class="hashoo-modal-inner">
            <div id="hashoo-receipt"></div>
            <div class="hashoo-modal-actions">
              <button class="hashoo-btn" id="hashoo-print">Print Bill</button>
              <button class="hashoo-btn secondary" id="hashoo-close">Close</button>
            </div>
          </div>
        </div>
      </div>
    `;

    $('#hashoo-pos-app').html(html);

    bindEvents();
    resetAndLoad();
    renderCart();
    updateSummary();
  }

  function bindEvents() {
    let t = null;

    $('#hashoo-search').on('input', function () {
      clearTimeout(t);
      term = $(this).val().trim();
      t = setTimeout(() => resetAndLoad(), 250);
    });

    $('#hashoo-paid').on('input', function () {
      updateSummary();
    });

    $('#hashoo-pay').on('click', function () {
      createOrder();
    });

    $('#hashoo-close').on('click', function () {
      $('#hashoo-modal').hide();
    });

    $('#hashoo-modal').on('click', function (e) {
      if (e.target.id === 'hashoo-modal') $('#hashoo-modal').hide();
    });

    $('#hashoo-print').on('click', function () {
      printReceipt();
    });

    // infinite scroll in product grid
    $('#hashoo-products').on('scroll', function () {
      const el = this;
      if (!hasMore || loading) return;
      if (el.scrollTop + el.clientHeight >= el.scrollHeight - 120) {
        loadProducts();
      }
    });

    // event delegation (better)
    $('#hashoo-products').on('click', '.hashoo-product-card', function () {
      const id = Number($(this).data('id'));
      const p = productsCache.find(x => Number(x.id) === id);
      if (!p || !Number(p.in_stock)) return;
      addToCart(p);
    });

    $('#hashoo-cart').on('click', '[data-act]', function () {
      const act = $(this).data('act');
      const id = Number($(this).data('id'));
      const idx = cart.findIndex(x => x.product_id === id);
      if (idx === -1) return;

      if (act === 'inc') cart[idx].qty += 1;
      if (act === 'dec') cart[idx].qty = Math.max(1, cart[idx].qty - 1);
      if (act === 'rm') cart.splice(idx, 1);

      renderCart();
    });
  }

  function resetAndLoad() {
    page = 1;
    productsCache = [];
    hasMore = true;
    $('#hashoo-products').html('');
    loadProducts(true);
  }

  function loadProducts(reset = false) {
    if (loading || !hasMore) return;
    loading = true;
    $('#hashoo-loader').show();

    $.post(HASHOO_POS.ajaxUrl, {
      action: 'hashoo_pos_get_products',
      nonce: HASHOO_POS.nonce,
      term: term,
      page: page,
      per_page: PER_PAGE
    }).done(res => {
      if (!res || !res.success) return;

      const list = res.data.products || [];
      hasMore = !!res.data.has_more;

      productsCache = productsCache.concat(list);
      renderProducts(list, reset);

      page += 1;
    }).always(() => {
      loading = false;
      $('#hashoo-loader').hide();
    });
  }

  function renderProducts(list, reset) {
    const $wrap = $('#hashoo-products');

    if (reset && (!list || !list.length)) {
      $wrap.html(`<div class="hashoo-empty">No products found.</div>`);
      return;
    }

    const html = (list || []).map(p => {
      const disabled = Number(p.in_stock) ? '' : 'disabled';
      const stockClass = Number(p.in_stock) ? 'stock' : 'oos';
      return `
        <button class="hashoo-product-card" type="button" data-id="${p.id}" ${disabled}>
          <div class="img">
            ${p.img ? `<img src="${p.img}" alt="">` : `<div class="ph"></div>`}
          </div>
          <div class="name">${escapeHtml(p.name)}</div>
          <div class="price">${money(p.price)}</div>
          <div class="meta ${stockClass}">${escapeHtml(p.stock_text || '')}</div>
        </button>
      `;
    }).join('');

    $wrap.append(html);
  }

  function addToCart(p) {
    const addId = Number(p.add_id || p.id);
    const existing = cart.find(x => x.product_id === addId);

    if (existing) existing.qty += 1;
    else {
      cart.push({
        product_id: addId,
        display_name: p.name,
        price: Number(p.price),
        qty: 1
      });
    }

    // ✅ sound on add product
    playBeep();

    renderCart();
  }

  function renderCart() {
    const $wrap = $('#hashoo-cart');

    if (!cart.length) {
      $wrap.html(`<div class="hashoo-empty">Cart is empty</div>`);
      updateSummary();
      return;
    }

    const html = cart.map(it => `
      <div class="hashoo-cart-item">
        <div class="left">
          <div class="nm">${escapeHtml(it.display_name)}</div>
          <div class="sm">${money(it.price)} each</div>
        </div>

        <div class="right">
          <div class="qty">
            <button class="mini" type="button" data-act="dec" data-id="${it.product_id}">−</button>
            <span>${it.qty}</span>
            <button class="mini" type="button" data-act="inc" data-id="${it.product_id}">+</button>
            <button class="mini danger" type="button" data-act="rm" data-id="${it.product_id}">×</button>
          </div>
          <div class="ln">${money(it.price * it.qty)}</div>
        </div>
      </div>
    `).join('');

    $wrap.html(html);

    updateSummary();
  }

  function updateSummary() {
    const total = calcTotal();
    const paid = Number($('#hashoo-paid').val() || 0);
    const change = Math.max(0, paid - total);

    $('#hashoo-total').text(money(total));
    $('#hashoo-count').text(itemCount());
    $('#hashoo-change').text(money(change));

    const canPay = cart.length > 0 && paid >= total;
    $('#hashoo-pay').prop('disabled', !canPay);

    if (cart.length > 0 && !canPay) {
      $('#hashoo-msg').html(`<div class="warn">Paid must be equal or greater than total.</div>`);
    } else {
      $('#hashoo-msg').html('');
    }
  }

  // ✅ show modal instantly, then replace receipt html when response arrives
  function createOrder() {
    const paid = Number($('#hashoo-paid').val() || 0);
    const paymentType = $('#hashoo-payment').val() || 'cash';

    $('#hashoo-msg').html('');

    // open modal immediately
    $('#hashoo-receipt').html(`
      <div class="hashoo-receipt-loading">
        <div class="spinner"></div>
        <div class="txt">Generating receipt…</div>
      </div>
    `);
    $('#hashoo-modal').css('display', 'flex');

    const $btn = $('#hashoo-pay');
    const oldText = $btn.text();
    $btn.prop('disabled', true).text('Processing…');

    $.post(HASHOO_POS.ajaxUrl, {
      action: 'hashoo_pos_create_order',
      nonce: HASHOO_POS.nonce,
      items: JSON.stringify(cart.map(x => ({ product_id: x.product_id, qty: x.qty }))),
      paid_amount: paid,
      payment_type: paymentType
    }).done(res => {
      if (!res || !res.success) {
        $('#hashoo-receipt').html(`<div class="hashoo-receipt-error">${escapeHtml(res?.data?.message || 'Error')}</div>`);
        return;
      }

      $('#hashoo-receipt').html(res.data.receipt_html || '');

      // reset
      cart = [];
      $('#hashoo-paid').val('0');
      renderCart();
    }).always(() => {
      $btn.prop('disabled', false).text(oldText);
    });
  }

  function printReceipt() {
    const receiptHtml = document.getElementById('hashoo-receipt').innerHTML;

    const w = window.open('', 'hashoo_pos_print', 'width=420,height=800');
    w.document.write(`
      <html>
        <head>
          <title>Receipt</title>
          <style>
            body { margin: 12px; font-family: ui-monospace, Menlo, Monaco, Consolas, "Courier New", monospace; }
            hr { border: none; border-top: 1px dashed #999; margin: 10px 0; }
            table { width: 100%; border-collapse: collapse; }
            th, td { padding: 6px 0; text-align: left; }
            .hashoo-receipt__footerbar{
              background:#000;color:#fff;text-align:center;
              padding:10px;margin-top:10px;font-weight:700;
            }
            .r-biz{ font-weight:900; font-size:18px; text-align:center; }
            .r-phone{ text-align:center; opacity:.85; margin-top:4px; }
            .r-meta{ margin-top:10px; font-size:12px; opacity:.9; }
          </style>
        </head>
        <body>${receiptHtml}</body>
      </html>
    `);
    w.document.close();
    w.focus();
    w.print();
    w.close();
  }

  $(document).ready(function () {
    if (typeof HASHOO_POS === 'undefined') {
      $('#hashoo-pos-app').html('<div style="padding:12px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;">Hashoo POS error: localization missing.</div>');
      return;
    }

    initBeep();
    renderApp();
  });

})(jQuery);
